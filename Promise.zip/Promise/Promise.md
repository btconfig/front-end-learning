title: promise 简介
speaker: paji
url: https://github.com/ksky521/nodeppt
transition: cover-diamond
files: 
theme: dark
highlightStyle: monokai_sublime
usemathjax: yes 启用MathJax渲染公式
[slide]

# promise 简介
## 分享人：paji

[slide data-transition="cover-diamond"]
<h1>Promise 简介</h1>
<li>所谓Promise，简单说就是一个容器，里面保存着某个未来才会结束的事件（通常是一个异步操作）的结果。</li>
<li>从语法上说，Promise 是一个对象，从它可以获取异步操作的消息。</li>
<li>Promise 提供统一的 API，各种异步操作都可以用同样的方法进行处理。</li>
<p>特点：</p>
<ol>
<li>Promise对象代表一个异步操作。内部有三种状态：pending（进行中）、fulfilled（已成功）和rejected（已失败)。只有异步操作的结果，可以决定当前是哪一种状态，任何其他操作都无法改变这个状态。</li>
<li>Promise的状态一旦改变，会发生凝固，以后可以在任何时候得到这个结果。
 Promise对象的状态改变，只有两种可能：从pending->fulfilled和从pending->rejected。
</li>
</ol>
<style>
  li{
    text-align:left;
    font-size: 22px;
    line-height:26px;
  }
  p{
    text-align:left;
  }
</style>
[slide data-transition="zoomin"]

<p>ES6 规定，Promise对象是一个构造函数，用来生成Promise实例。</p>

```javascript
  const promise = new Promise(function(resolve, reject) {
  // ... some code

  if (/* 异步操作成功 */){
    resolve(value);
  } else {
    reject(error);
  }
});
```
[slide data-transition="newspaper"]
<p>Promise.prototype.then()</p>
<p>Promise.prototype.catch()</p>
<p>Promise实例生成以后，可以用then,catch方法分别指定resolved状态和rejected状态的回调函数。</p>

```javascript
const promise = new Promise(function (resolve, reject) {
  // ... some code

  if (/* 异步操作成功 */){
    resolve(value);
  } else {
    reject(error);
  }
})
promise
  .then(res => console.log(res))
  .catch(error => console.log(error))
```
[slide data-transition="zoomout"]
<p>Promise.prototype.finally()</p>
<p>finally方法用于指定不管 Promise 对象最后状态如何，都会执行的操作。该方法是 ES2018 引入标准的。</p>

```javascript
promise
 .then(result => {···})
 .catch(error => {···})
 .finally(() => {···});
``` 

[slide data-transition="zoomin"]
<p>Promise.all()</p>
<p>Promise.all方法用于将多个 Promise 实例，包装成一个新的 Promise 实例。</p>

```javascript
const p = Promise.all([p1, p2, p3]);
```
<p>p的状态由p1、p2、p3决定，分成两种情况。
<ol><li>
只有p1、p2、p3的状态都变成fulfilled，p的状态才会变成fulfilled，此时p1、p2、p3的返回值组成一个数组，传递给p的回调函数。</li>
<li>
只要p1、p2、p3之中有一个被rejected，p的状态就变成rejected，此时第一个被reject的实例的返回值，会传递给p的回调函数。</li></p>
[slide data-transition="cover-diamond"]
<p>Promise.race()</p>
<p>Promise.race方法同样是将多个 Promise 实例，包装成一个新的 Promise 实例。</p>

```javascript
const p = Promise.race([p1, p2, p3]);
```

<p>只要p1、p2、p3之中有一个实例率先改变状态，p的状态就跟着改变。那个率先改变的 Promise 实例的返回值，就传递给p的回调函数。</p>
[slide data-transition="earthquick"]
<p>Promise.resolve()</p>
<p>Promise.reject()</p>
<p>这两个方法会返回一个新的 Promise 实例</p>
[slide data-transition="cover-circle"]
<p>下面我们来实现一个Promise</p>
<p>从最为基础的一个应用实例开始探索</p>

```javascript
function getUserId() {
	return new Promise(function (resolve) {
		// 模拟异步操作
		window.setTimeout(function () {
			resolve(21);
		}, 1000);
	});
}

getUserId().then(function (id) {
	console.log(id);
});
```
[slide data-transition="horizontal3d"]
<p>最基础的Promise的实现</p>

```javascript
function Promise(fn) {
  var value = null,
  callbacks = [];  //callbacks为数组，因为可能同时有很多个回调
        
  this.then = function (onFulfilled) {
    callbacks.push(onFulfilled);
  };
    
  function resolve(value) {
    callbacks.forEach(function (callback) {
      callback(value);
    });
  }

  fn(resolve);
}
```
[slide data-transition="move"]
<p>我们看到then是链式的，我们来添加链式</p> 

```javascript
this.then = function (onFulfilled) {
  callbacks.push(onFulfilled);
  return this;
};
```
```javascript
getUserId().then(function (id) {
  // 一些处理
}).then(function (id) {
  // 一些处理
});
```
[slide data-transition="vertical3d"]
<p>如果Promise内部的函数是个同步函数怎么办？</p>

```javascript
function getUserId() {
  return new Promise(function (resolve) {
      resolve(21);
  });
}
getUserId().then(function (id) {
  // 一些处理
});
```
<p>所以我们加入一些延时</p>

```javascript
function resolve(value) {
  setTimeout(function() {
      callbacks.forEach(function (callback) {
          callback(value);
      });
  }, 0)
} 
```

[slide data-transition="circle"]
<p>加入状态</p>

```javascript
function Promise(fn) {
  var state = 'pending',
      value = null,
      callbacks = [];

  this.then = function (onFulfilled) {
      if (state === 'pending') {
          callbacks.push(onFulfilled);
          return this;
      }
      onFulfilled(value);
      return this;
  };

  function resolve(newValue) {
      value = newValue;
      state = 'fulfilled';
      setTimeout(function () {
        callbacks.forEach(function (callback) {
            callback(value);
        });
      }, 0);
  }

  fn(resolve);
}
```
[slide data-transition="vertical3d"]
<p>链式Promise</p>
<p>如果用户再then函数里面注册的仍然是一个Promise，怎么办</p>

```javascript
getUserId()
  .then(getUserJobById)
  .then(function (job) {
      // 对job的处理
  });

function getUserJobById(id) {
  return new Promise(function (resolve) {
    http.get(baseUrl + id, function(job) {
        resolve(job);
    });
  });
}
```
[slide data-transition="cards"]
<div class="columns-2">
 <pre><code class="javascript">
 function Promise(fn) {
  var state = 'pending',
    value = null,
    callbacks = [];

  this.then = function (onFulfilled) {
    return new Promise(function (resolve) {
      handle({
          onFulfilled: onFulfilled || null,
          resolve: resolve
      });
    });
  };

  function handle(callback) {
    if (state === 'pending') {
      callbacks.push(callback);
      return;
    }
    //如果then中没有传递任何东西
    if(!callback.onFulfilled) {
      callback.resolve(value);
      return;
    }

    var ret = callback.onFulfilled(value);
    callback.resolve(ret);
  }
    </code></pre>
<pre><code class="javascript">
  function resolve(newValue) {
    if (newValue && (typeof newValue === 'object' || typeof newValue === 'function')) {
      var then = newValue.then;
      if (typeof then === 'function') {
        then.call(newValue, resolve);
        return;
      }
    }
    state = 'fulfilled';
    value = newValue;
    setTimeout(function () {
      callbacks.forEach(function (callback) {
        handle(callback);
      });
    }, 0);
  }

  fn(resolve);
}
    </code></pre>
</div>

[slide data-transition="stick"]
<p>失败处理</p>

```javascript
function getUserId() {
  return new Promise(function(resolve) {
    //异步请求
    http.get(url, function(error, results) {
      if (error) {
        reject(error);
      }
      resolve(results.id)
    })
  })
}

getUserId().then(function(id) {
  //一些处理
}, function(error) {
  console.log(error)
})
```
[slide data-transition="slide3"]
<div class="columns-2">
 <pre><code class="javascript">
 function Promise(fn) {
  var state = 'pending',
    value = null,
    callbacks = [];

  this.then = function (onFulfilled, onRejected) {
    return new Promise(function (resolve, reject) {
      handle({
        onFulfilled: onFulfilled || null,
        onRejected: onRejected || null,
        resolve: resolve,
        reject: reject
      });
    });
  };

  function handle(callback) {
    if (state === 'pending') {
      callbacks.push(callback);
      return;
    }

    var cb = state === 'fulfilled' ? callback.onFulfilled : callback.onRejected,
      ret;
    if (cb === null) {
      cb = state === 'fulfilled' ? callback.resolve : callback.reject;
      cb(value);
      return;
    }
    ret = cb(value);
    callback.resolve(ret);
  }
 </code></pre>
 <pre><code class="javascript">
 function resolve(newValue) {
    if (newValue && (typeof newValue === 'object' || typeof newValue === 'function')) {
      var then = newValue.then;
      if (typeof then === 'function') {
        then.call(newValue, resolve, reject);
        return;
      }
    }
    state = 'fulfilled';
    value = newValue;
    execute();
  }

  function reject(reason) {
    state = 'rejected';
    value = reason;
    execute();
  }

  function execute() {
    setTimeout(function () {
      callbacks.forEach(function (callback) {
          handle(callback);
      });
    }, 0);
  }

  fn(resolve, reject);
}
 </code></pre>
</div>
[slide data-transition="slide2"]
<p>异常处理</p>

```javascript
function handle(callback) {
  if (state === 'pending') {
    callbacks.push(callback);
    return;
  }

  var cb = state === 'fulfilled' ? callback.onFulfilled : callback.onRejected,
    ret;
  if (cb === null) {
    cb = state === 'fulfilled' ? callback.resolve : callback.reject;
    cb(value);
    return;
  }
  try {
    ret = cb(value);
    callback.resolve(ret);
  } catch (e) {
    callback.reject(e);
  } 
}
```
[slide data-transition="slide"]
<p>相关文档：</p>
<li>[Promise/A+规范](https://promisesaplus.com/)</li>
<li>[剖析 Promise 之基础篇](https://github.com/expressjs/body-parser)</li>
<li>[阮一峰es6入门](http://es6.ruanyifeng.com/#docs/promise)</li>
<li>[Promise 必知必会（十道题）](https://zhuanlan.zhihu.com/p/30797777)</li>
[slide data-transition="slide"]
<div>
谢谢大家～～
</div>