//我们根据一个应用实例来看看Promise的实现过程

/*
* Step One: 实现基础
*/

//eg.1 一个获取用户id的请求处理
function getUserId() {
  return new Promise(function (resolve) {
    // 模拟异步操作
    window.setTimeout(function () {
      resolve(21);
    }, 1000);
  });
}

getUserId().then(function (id) {
  console.log(id);
});

//getUserId方法返回一个promise，可以通过它的then方法注册(注意注册这个词)在promise异步操作成功时执行的回调。

function Promise(fn) {
  var value = null,
    callbacks = [];  //callbacks为数组，因为可能同时有很多个回调

  this.then = function (onFulfilled) {
    callbacks.push(onFulfilled);
  };

  function resolve(value) {
    callbacks.forEach(function (callback) {
      callback(value);
    });
  }

  fn(resolve);  
}

//调用then方法，将想要在Promise异步操作成功时执行的回调放入callbacks队列，其实也就是注册回调函数
//创建Promise实例时传入的函数会被赋予一个函数类型的参数，即resolve，
//它接收一个参数value，代表异步操作返回的结果，当一步操作执行成功后，
//用户会调用resolve方法，这时候其实真正执行的操作是将callbacks队列中的回调一一执行；

//可以结合例1中的代码来看，首先new Promise时，传给promise的函数发送异步请求，
//接着调用promise对象的then属性，注册请求成功的回调函数，
//然后当异步请求发送成功时，调用resolve(results.id)方法, 该方法执行then方法注册的回调数组。

/*
*在平时应用过程中，then方法应该能够链式调用，但是上面的最基础实现无法支持链式调用。
*想让then方法支持链式调用，其实也是很简单的：
*/
this.then = function (onFulfilled) {
  callbacks.push(onFulfilled);
  return this;
};

/*
* Step Two: 加入延时
*/

//上述代码可能还存在一个问题：如果在then方法注册回调之前，resolve函数就执行了，怎么办？
//比如promise内部的函数是同步函数：
//eg.2
function getUserId() {
  return new Promise(function (resolve) {
    resolve(21);
  });
}
getUserId().then(function (id) {
  // 一些处理
});

/*
*Promises/A+ 规范明确要求回调需要通过异步方式执行，用以保证一致可靠的执行顺序。
*所以我们可以通过 setTimeout 将 resolve 中执行回调的逻辑放置到 JS 任务队列末尾
*保证在resolve执行之前，then方法已经注册完所有的回调.
*/
function resolve(value) {
  setTimeout(function () {
    callbacks.forEach(function (callback) {
      callback(value);
    });
  }, 0)
}

/*
* Step Three: 加入状态
*/

//上面代码中，还有一个问题：
//如果Promise异步操作已经成功，这时，在异步操作成功之前注册的回调都会执行，
//但是在Promise异步操作成功这之后调用的then注册的回调就再也不会执行了。
//为了解决这个问题，我们加入状态机制，也就是pending、fulfilled、rejected三种状态。
/*
*Promises/A+规范中的2.1Promise States中明确规定了，pending可以转化为fulfilled或rejected并且只能转化一次，
*也就是说如果pending转化到fulfilled状态，那么就不能再转化到rejected。
*并且fulfilled和rejected状态只能由pending转化而来，两者之间不能互相转换。
*/

function Promise(fn) {
  var state = 'pending',
    value = null,
    callbacks = [];

  this.then = function (onFulfilled) {
    if (state === 'pending') {
      callbacks.push(onFulfilled);
      return this;
    }
    onFulfilled(value);
    return this;
  };

  function resolve(newValue) {
    value = newValue;
    state = 'fulfilled';
    setTimeout(function () {
      callbacks.forEach(function (callback) {
        callback(value);
      });
    }, 0);
  }

  fn(resolve);
}
//resolve执行时，会将状态设置为fulfilled，在此之后调用then添加的新回调，都会立即执行。
//这里没有任何地方将state设为rejected，后面会有一小节专门加入。

/*
* Step Four: 链式Promise
*/

//eg.3
getUserId()
  .then(getUserJobById)
  .then(function (job) {
    // 对job的处理
  });

function getUserJobById(id) {
  return new Promise(function (resolve) {
    http.get(baseUrl + id, function (job) {
      resolve(job);
    });
  });
}

/*
*这种场景大家都是经常会遇到的
*链式Promise是指在当前promise达到fulfilled状态后，即开始进行下一个promise（后邻promise）。
*那么我们只要在then方法里面return一个promise就好啦。
*/
function Promise(fn) {
  var state = 'pending',


    value = null,
    callbacks = [];

  this.then = function (onFulfilled) {
    return new Promise(function (resolve) {
      handle({
        onFulfilled: onFulfilled || null,
        resolve: resolve
      });
    });
  };

  function handle(callback) {
    if (state === 'pending') {
      callbacks.push(callback);
      return;
    }
    //如果then中没有传递任何东西
    if (!callback.onFulfilled) {
      callback.resolve(value);
      return;
    }

    var ret = callback.onFulfilled(value);
    callback.resolve(ret);
  }

  function resolve(newValue) {
    if (newValue && (typeof newValue === 'object' || typeof newValue === 'function')) {
      var then = newValue.then;
      if (typeof then === 'function') {
        then.call(newValue, resolve);
        return;
      }
    }
    state = 'fulfilled';
    value = newValue;
    setTimeout(function () {
      callbacks.forEach(function (callback) {
        handle(callback);
      });
    }, 0);
  }

  fn(resolve);
}
//我们结合例3，来分析上面的代码逻辑
/*
*1.then 方法中，创建了一个新的 Promise 实例，并作为返回值，这类 promise，权且称作 bridge promise。
*这是串行 Promise 的基础。另外，因为返回类型一致，之前的链式执行仍然被支持；
*2.handle 方法是当前 promise 的内部方法。then 方法传入的形参 onFullfilled，
*以及创建新 Promise 实例时传入的 resolve 均被压入当前 promise 的 callbacks 队列中。
*而这，正是衔接当前 promise 与后邻 promise 的关键。
*3.新增的 handle 方法，相比改造之前的 then 方法，仅增加了一行代码：callbacks.resolve(ret);
*这意味着当前 promise 异步操作成功后执行 handle 方法时，先执行 onFulfilled 方法，
*然后将其返回值作为实参执行 resolve 方法，而这标志着后邻 promise 异步操作成功！
*
*结合eg.3
*1.getUserId生成的promise（简称getUserId promise）异步操作成功，
*执行其内部方法resolve，传入的参数正是异步操作的结果id
*2.调用 handle 方法处理 callbacks 队列中的回调：getUserJobById 方法，
*生成新的 promise（简称 getUserJobById promise）；
*3.执行之前由 getUserId promise 的 then 方法生成的 bridge promise 的 resolve 方法，
*传入参数为 getUserJobById promise。这种情况下，会将该resolve方法传入getUserJobById promise的then方法中，并直接返回；
*4.在 getUserJobByIdd promise 异步操作成功时，执行其 callbacks 中的回调：getUserId bridge promise 的 resolve 方法；
*5.最后，执行 getUserId bridge promise 的后邻 promise 的 callbacks 中的回调
*/


/*
* Step Five: 失败处理
*/

//eg.4
function getUserId() {
  return new Promise(function (resolve) {
    //异步请求
    http.get(url, function (error, results) {
      if (error) {
        reject(error);
      }
      resolve(results.id)
    })
  })
}

getUserId().then(function (id) {
  //一些处理
}, function (error) {
  console.log(error)
})
//根据fulfilled状态，我们添加rejected状态

function Promise(fn) {
  var state = 'pending',
    value = null,
    callbacks = [];

  this.then = function (onFulfilled, onRejected) {
    return new Promise(function (resolve, reject) {
      handle({
        onFulfilled: onFulfilled || null,
        onRejected: onRejected || null,
        resolve: resolve,
        reject: reject
      });
    });
  };

  function handle(callback) {
    if (state === 'pending') {
      callbacks.push(callback);
      return;
    }

    var cb = state === 'fulfilled' ? callback.onFulfilled : callback.onRejected,
      ret;
    if (cb === null) {
      cb = state === 'fulfilled' ? callback.resolve : callback.reject;
      cb(value);
      return;
    }
    ret = cb(value);
    callback.resolve(ret);
  }

  function resolve(newValue) {
    if (newValue && (typeof newValue === 'object' || typeof newValue === 'function')) {
      var then = newValue.then;
      if (typeof then === 'function') {
        then.call(newValue, resolve, reject);
        return;
      }
    }
    state = 'fulfilled';
    value = newValue;
    execute();
  }

  function reject(reason) {
    state = 'rejected';
    value = reason;
    execute();
  }

  function execute() {
    setTimeout(function () {
      callbacks.forEach(function (callback) {
        handle(callback);
      });
    }, 0);
  }

  fn(resolve, reject);
}

/**
 * 上述代码增加了新的reject方法，供异步操作失败时调用，同时抽出了resolve和reject共用的部分，形成execute方法。
 * 错误冒泡是上述代码已经支持，且非常实用的一个特性。在handle中发现没有指定异步操作失败的回调时，
 * 会直接将bridge promise(then函数返回的promise，后同)设为rejected状态，如此达成执行后续失败回调的效果。
 * 这有利于简化串行Promise的失败处理成本，因为一组异步操作往往会对应一个实际功能，失败处理方法通常是一致的：
 */

/*
* Step Five: 异常处理
*/

//如果在执行成功回调、失败回调时代码出错怎么办？对于这类异常，可以使用try-catch捕获错误，并将bridge promise设为rejected状态。
function handle(callback) {
  if (state === 'pending') {
    callbacks.push(callback);
    return;
  }

  var cb = state === 'fulfilled' ? callback.onFulfilled : callback.onRejected,
    ret;
  if (cb === null) {
    cb = state === 'fulfilled' ? callback.resolve : callback.reject;
    cb(value);
    return;
  }
  try {
    ret = cb(value);
    callback.resolve(ret);
  } catch (e) {
    callback.reject(e);
  }
}

//代码就如下：
function Promise(fn) {
  var state = 'pending',
    value = null,
    callbacks = [];

  this.then = function (onFulfilled, onRejected) {
    return new Promise(function (resolve, reject) {
      handle({
        onFulfilled: onFulfilled || null,
        onRejected: onRejected || null,
        resolve: resolve,
        reject: reject
      });
    });
  };

  function handle(callback) {
    if (state === 'pending') {
      callbacks.push(callback);
      return;
    }

    var cb = state === 'fulfilled' ? callback.onFulfilled : callback.onRejected,
      ret;
    if (cb === null) {
      cb = state === 'fulfilled' ? callback.resolve : callback.reject;
      cb(value);
      return;
    }
    try {
      ret = cb(value);
      callback.resolve(ret);
    } catch (e) {
      callback.reject(e);
    }
  }

  function resolve(newValue) {
    if (newValue && (typeof newValue === 'object' || typeof newValue === 'function')) {
      var then = newValue.then;
      if (typeof then === 'function') {
        then.call(newValue, resolve, reject);
        return;
      }
    }
    state = 'fulfilled';
    value = newValue;
    execute();
  }

  function reject(reason) {
    state = 'rejected';
    value = reason;
    execute();
  }

  function execute() {
    setTimeout(function () {
      callbacks.forEach(function (callback) {
        handle(callback);
      });
    }, 0);
  }

  fn(resolve, reject);
}